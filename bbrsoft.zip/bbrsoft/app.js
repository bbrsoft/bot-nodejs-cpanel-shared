const http = require('http');
const https = require('https');

const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('<html><body><h1>Server is running and making requests every 3600000 seconds = 1 jam.</h1></body></html>');
});

function fetchData() {
    https.get('https://disraya.info/id/subscriptions/recently-expired', (response) => {
        let data = '';

        response.on('data', (chunk) => {
            data += chunk;
        });

        response.on('end', () => {
            console.log('Data fetched successfully:', data);
            // Anda bisa menambahkan logika lain di sini untuk memproses data
        });
    }).on('error', (err) => {
        console.error('Error: ' + err.message);
    });
}

// Jalankan fetchData setiap 10 detik
setInterval(fetchData, 3600000); // 3600000 ms = 1 jam

const port = process.env.PORT || 3000;
server.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
