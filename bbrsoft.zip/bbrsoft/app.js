const http = require('http');
const https = require('https');

const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    
    // Mengakses URL
    https.get('https://intrust.live/bot.php', (response) => {
        let data = '';

        // Menangkap data yang diterima
        response.on('data', (chunk) => {
            data += chunk;
        });

        // Setelah semua data diterima
        response.on('end', () => {
            res.end(`<html><body><h1>Response from bot.php</h1><pre>${data}</pre></body></html>`);
        });
    }).on('error', (err) => {
        console.error('Error: ' + err.message);
        res.end('Error fetching data');
    });
});

const port = process.env.PORT || 3000;
server.listen(port, () => {
    console.log(`Server running at http://disraya.info/bbrsoftbot/`);
});
